#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>


/*****COPYRIGHT NOTICE****

Quadparser - a program to search for quadruplex-forming regions in DNA
Copyright (C) 2005 Julian Huppert and Simon Rodgers

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

The GNU Lesser General Public License is available from 
http://www.gnu.org/copyleft/lesser.html; you can also write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

****END COPYRIGHT NOTICE*****/

#define	VERSION "2.0"
#define	CHROMOSOMESTARTCOUNTMARKER "bases "

char* szFilename = NULL;
char* szBases = NULL;
int nBasesInRepeat = 0;
int nRepeatsInSequence = 0;
int nMinGap = 0;
int nMaxGap = 0;
FILE* fpOutput = NULL;
char* szFileContents = NULL;
char* szFileOutput = NULL;
int nRuns = 0;
int bToFile = 1;
char* szOutputStyle = NULL;
char* szPrefix = NULL;
int nMyOffset = 0;

char *eliminateChar(char* szString, char cToRemove)
{
	char* pPos=szString;
	int nPos=0;
	while(*pPos)
	{
		if (*pPos!=cToRemove)
		{
			szString[nPos]=*pPos;
			nPos++;
		}
		pPos++;
	}
	szString[nPos]=0;
	return szString;
}


long fileLength(FILE* pStream)
{
    if (pStream)
    {
        long lnLength = 0L;
        long lnPos = 0L;
        lnPos = ftell(pStream);
        fseek (pStream, 0, SEEK_END);
        lnLength = ftell(pStream);
        fseek(pStream, lnPos, SEEK_SET);
		
        return lnLength;
    }
    return 0L;
}



/* Read a file into a buffer just the right size */
long fileReadInToBuffer(FILE* pFile,char** pacBuffer)
{
    /* Make it one bigger to work with text files into a nulled buffer - that way they are zero terminated too!*/
    long lnBufferLength = fileLength(pFile)+2;
    long lnBytesRead = 0L;
    if (pacBuffer)
    {
        *pacBuffer = (char *)calloc(sizeof(char)*(lnBufferLength),sizeof(char));
        if (*pacBuffer)
        {
			//make sure that you open the file in binary, opening it in ASCII will convert the carriage
			//returns and lnBytesRead !=(lnBufferLength-2)
            lnBytesRead = fread( *pacBuffer, sizeof(char), lnBufferLength, pFile);
        }
    }
    if(lnBytesRead==0)
	{
		free(*pacBuffer);
	}
    /* Return the actual amount read - not the buffer size */
	return lnBytesRead;
}

void init(int argc, char *argv[])
{
	FILE* fpInput = NULL;
	int ii,jj,kk;
	
	if (argc == 2 && strcmp(argv[1], "-version") == 0 || argc==2 && strcmp(argv[1], "-v") == 0)
	{
		printf("\nseqparser version %s\n", VERSION);
		printf("version history:\n");
		printf("0.1\t04-09-03\tInitial version\n");
		//		printf("0.2\t11-09-03\tRemoves line feeds\n");
		//		printf("\t\t\tAccepts FASTA format\n");
		//		printf("0.3\t16-09-03\tAccepts multiple bases at input\n");
		//		printf("\t\t\tExports output to file\n");
		//		printf("\t\t\tChromosome name/number prepends output line\n");
		//		printf("\t\t\tVersion information\n");
		//		printf("\t\t\tProper treatment of poly {G} repeats\n");
		//		printf("0.4\t04-12-03\tFixed detection bug\n");
		//		printf("\t\t\tTreats CCCCCCC type sequences correctly as (CCC)C(CCC)\n");
		//		printf("0.5\t11-12-03\tSearches through many concatenated files\n");
		//		printf("\t\t\tOutputs all information header\n");
		printf("1.0\t26-06-04\tRelease version\n");
		printf("\t\t\tOutput format controllable from input\n");
		printf("\t\t\tLoop counter installed\n");
		printf("\t\t\tGene stripper installed\n");
		printf("\t\t\tError catching introduced\n");
		printf("1.1\t10-11-04\tENSEMBL-Das enabled\n");
		printf("\t\t\tReleased as part of Huppert and Balasubramanian, NAR 2005\n");
		printf("2\t08-11-05\tSignificant updates for re-release\n");
		printf("\t\t\tbus error fixed\n");
		
		printf("\n");
		exit(0);
	}
	
	if (argc == 2 && strcmp(argv[1], "-help") == 0 || argc==2 && strcmp(argv[1], "-h") == 0 || argc==2 && strcmp(argv[1], "-man") == 0 || argc==2 && strcmp(argv[1], "-m") == 0)
	{	
		printf("\nquadparser version %s\n", VERSION);
		printf("Programme to search for quadruplex-forming sequences in DNA\n");
		printf("By Julian Huppert, Balsubramanian group, Cambridge University Chemical Laboratories\n");
		printf("And Simon Rodgers, thaze.com. \nReleased under the Lesser GPL\n\n");
		printf("usage:\n\t%s <filename> <bases> <# bases in repeat> <repeats in sequence> <min gap size> <max gap size> <output file>\n\n", argv[0]);
		printf("ex:\t %s bases.txt CG 3 4 1 7 output.txt\n", argv[0]);
		printf("\t scans through bases.txt for CCC...CCC...CCC...CCC or GGG...GGG...GGG...GGG, where ... = 1-7 chars, writing into output.txt\n\n");
		printf("\t If <output file> is set to 'stdout', then output will be to the screen\n\n");
		
		printf("optional commands:\n-help\t-h\tgets help\n-man\t-m\topens the manual\n-version-v\tgives version information\n");
		printf("-normal\t-n\tuses standard parameters GC 3 4 1 7\tMust go first!\n");
		printf("\noutput styles:\n-default-d\tdefault output. Not required\n");
		printf("-pos\t-p\toutputs starting positions only\n");
		printf("-mid\t-m\toutputs midpoints only\n");
		printf("-coord\t-c\toutputs first and last positions only. optional prefix as last entry\n");
		printf("-number\t\toutputs number of quadruplexes only\n"); 
		printf("-header\t\toutputs hit headers and sequences\n");
		printf("-gene\t-g\toutputs gene name from header only\n");
		printf("-loop\t-l\toutputs table of loop length matches\n");
		printf("-ll\t\tabbreviated loop output\n");
		printf("-l2\t\tuncollated loop output\n");
		printf("-l3\t\toutput chr, start, end, loop lengths");
		printf("-DAS\t\toutputs data in format for DAS upload. Chr code required\n");
		printf("-BED\t\toutputs data in BED format. Chr code required\n");
		printf("\nExamples:\t%s -n bases.txt output.txt\n", argv[0]);
		printf("\t\t%s -n -c bases.txt output.txt 3\n", argv[0]);
		printf("\t\t%s -pos bases.txt GC 3 4 1 7 output.txt\n\n", argv[0]);
		
		exit(0);
	}
	
	//	allow default setting of parameters CG 3 4 1 7 
	if (argc > 3 && strcmp(argv[1], "-n") == 0 || argc > 3 && strcmp(argv[1], "-normal") == 0)
	{
		szBases = strdup("GC");
		nBasesInRepeat = 3;
		nRepeatsInSequence = 4;
		nMinGap = 1;
		nMaxGap = 7;
		
		if(argv[2][0] != '-')
		{
			szOutputStyle = strdup("-d");
			szFilename = strdup(argv[2]);
			szFileOutput = strdup(argv[3]);
			
		}
		//eg seqparser -n bases.txt output.txt
		else
		{
			szOutputStyle = strdup(argv[2]);
			szFilename = strdup(argv[3]);
			szFileOutput = strdup(argv[4]);
			
			if(argc>5 && (strcmp(szOutputStyle, "-coord") == 0 || strcmp(szOutputStyle, "-c") == 0|| strcmp(szOutputStyle, "-DAS") == 0 || strcmp(szOutputStyle, "-BED") == 0 || strcmp(szOutputStyle, "-l3") == 0)) 
			{	
			szPrefix=strdup(argv[5]);
				if (argc>6)
				{
					nMyOffset=atoi(argv[6]);
				}
				//to allow for ENCODE coordinates
			}
			else if(argc>5) {nMyOffset = atoi(argv[5]);}
		}
		//eg seqparser -n -pos bases.txt output.txt
	}
	
	else if(argc == 8 && argv[1][0] != '-')
	{
		szOutputStyle = strdup("-d");
		szFilename = strdup(argv[1]);
		szBases = strdup(argv[2]);
		nBasesInRepeat = atoi(argv[3]);
		nRepeatsInSequence = atoi(argv[4]);
		nMinGap = atoi(argv[5]);
		nMaxGap = atoi(argv[6]);
		szFileOutput = strdup(argv[7]);
		
	}
	
	else if(argc >8)
	{
		szOutputStyle = strdup(argv[1]);
		szFilename = strdup(argv[2]);
		szBases = strdup(argv[3]);
		nBasesInRepeat = atoi(argv[4]);
		nRepeatsInSequence = atoi(argv[5]);
		nMinGap = atoi(argv[6]);
		nMaxGap = atoi(argv[7]);
		szFileOutput = strdup(argv[8]);			
		
		if(argc >9 && (strcmp(szOutputStyle, "-coord") == 0 || strcmp(szOutputStyle, "-c") == 0 || strcmp(szOutputStyle, "-DAS") == 0 || strcmp(szOutputStyle, "-BED") == 0|| strcmp(szOutputStyle, "-l3") == 0))  
		{	
		szPrefix=strdup(argv[9]);
			if (argc>10)
			{
				nMyOffset=atoi(argv[10]);
			}
		}		//to allow for ENCODE coordinates
		else if(argc>9) {nMyOffset = atoi(argv[9]);}
	}
	
	else 
	{
		printf("Insufficient inputs. Try '%s -h' for assistance\n", argv[0]);
		exit(0);
	}
	
	if (!szFilename || !szBases || !nBasesInRepeat || !nRepeatsInSequence || !nMinGap || !nMaxGap || !szFileOutput)
	{
		printf("invalid parameters\n");
		exit(0);
	}
	
	//	printf("%s   %s   %s   %d   %d   %d   %d   %s\n", szOutputStyle, szFilename, szBases, nBasesInRepeat, nRepeatsInSequence, nMinGap, nMaxGap, szFileOutput);
	
	fpInput = fopen(szFilename, "r+b");
	if (!fpInput)
	{
		printf("file %s not found\n", szFilename);
		exit(0);
	}
	fileReadInToBuffer(fpInput, &szFileContents);
	fclose(fpInput);
	
	if (strcmp(szFileOutput, "stdout") == 0)
	{
		bToFile = 0;
	}
	else
	{
		printf("output to file %s\n", szFileOutput);
		fpOutput = fopen(szFileOutput, "w+b");
		
		if (!fpOutput)
		{
			printf("could not open file %s\n", szFileOutput);
			exit(0);
			
		}
	}
}

int main(int argc, char *argv[])
{
	init(argc, argv);
	
	if (szFileContents)
	{
		int nBases = strlen(szBases);
		int jj=0;
		
		char* pPos2 = szFileContents;
		int nBlocks = 0;
		int nSpace = 4;
		char** aszBlocks = calloc(sizeof(char*), nSpace);
		printf("\n");
		
		// build up an array of block start positions, and blank the kets
		while (1)
		{
			char* pKet = strchr(pPos2, '>');
			
			if (!pKet || !*pKet || !*(pKet+1))
				break;
			
			if (nBlocks >= nSpace)
			{
				nSpace *= 2;
				aszBlocks = realloc(aszBlocks, sizeof(char*) * nSpace);
			}
			
			*pKet = 0;
			pPos2 = pKet+1;
			
			aszBlocks[nBlocks] = pKet+1;
			
			nBlocks++;
		}
		
		for(; jj<nBlocks; jj++)
		{
			char* pStartHeader = aszBlocks[jj];
			int nBase=0;
			int nChromosomeOffset = 0;
			char* pStartSequence = strchr(pStartHeader, '\n');
			char* pEndHeader = NULL;
			
			if(strcmp(szOutputStyle, "-gene") == 0 || strcmp(szOutputStyle, "-g") == 0)
			{
				//				pStartHeader=strchr(aszBlocks[jj], '|');
				//				pStartHeader++;
				pEndHeader = strchr(pStartHeader, '.');
				*pEndHeader = 0;
			}
			
			if (pStartSequence && *pStartSequence && *(pStartSequence+1))
			{
				char* pChromosomeOffset = NULL;
				
				*pStartSequence = 0;
				pStartSequence++;
				
				pChromosomeOffset = strstr(pStartHeader, CHROMOSOMESTARTCOUNTMARKER);
				if (pChromosomeOffset)
					nChromosomeOffset = atoi(pChromosomeOffset + strlen(CHROMOSOMESTARTCOUNTMARKER));
				nChromosomeOffset += nMyOffset;
				// allows ENCODE correction
				
				//print header if wanted
				if (strcmp(szOutputStyle, "-d") == 0 || 
					strcmp(szOutputStyle, "-default") == 0
					)
					
				{
					if (bToFile)
						fprintf(fpOutput, "%s\n", pStartHeader);
					else
						printf("%s\n", pStartHeader);
				}
				
				if (strcmp(szOutputStyle, "-DAS") == 0)
				{
					if (bToFile)
						fprintf(fpOutput, "track name=Quadruplexes\n");
					else
						printf("track name=Quadruplexes\n");
				}
				
				if (strcmp(szOutputStyle, "-BED") == 0)
				{
					if (bToFile)
						fprintf(fpOutput, "track name=quadruplexes description=\"PQS predicted by quadparser\" useScore=0\n");
					else
						printf("track name=quadruplexes description=\"PQS predicted by quadparser\" useScore=0\n");
				}
				
				for (; nBase<nBases; nBase++)
				{
					char* pPos = pStartSequence;
					char* szMatch = calloc(1, nBasesInRepeat + 1);
					char* pStartPos = NULL;
					char* pLastEndSeq = NULL;
					int nSequencesFound = 0;
					int nOverlappingSequencesFound = 0;
					int nRunsFound = 0;
					int bContinue = 1;
					char* pLastPos = NULL;
					char cBase = szBases[nBase];
					int anLoopCount[20][20][20];
					int anLoopFrequency [3][7];
					int ii,jj,kk;
					char cStrand = 0; 
					
					for (ii=0; ii<nMaxGap; ii++)
					{
						for (jj=0; jj<nMaxGap; jj++)
						{
							for (kk=0; kk<nMaxGap; kk++)
							{
								
								anLoopCount[ii][jj][kk]=0;
							}
						}
					}
					
					for (ii=0;ii<3;ii++)
					{
						for (jj=0; jj<7 ; jj++)
						{
							anLoopFrequency[ii][jj]=0;
						}
					}
					
					memset(szMatch, (int)cBase, nBasesInRepeat);
					
					eliminateChar(pPos, '\r');
					eliminateChar(pPos, '\n');
					
					//print info titles if writing to screen or if default output style
					//					if (bToFile && (strcmp(szOutputStyle, "-d") == 0 || strcmp(szOutputStyle, "-default") ==0))
					//						fprintf(fpOutput, "\nSearching for %d or more sequences of %d '%c' bases\n\n", nRepeatsInSequence, nBasesInRepeat, cBase);
					//					else if (!bToFile)
					//						printf("\nSearching for %d or more sequences of %d '%c' bases\n\n", nRepeatsInSequence, nBasesInRepeat, cBase);
					
					
					while (bContinue)
					{
						
						char cTemp = 0;
						int anRollingLoop [3] = {0,0,0};
						char* apStartPos [4] = {NULL,NULL,NULL,NULL};
						ii=0;
						jj=0;
						
						while (1)
						{
							int n=0;
							// find next occurrence of the CCC style sequence
							pLastPos = pPos;
							pPos = strstr(pPos, szMatch);
							
							// none left - start the next base
							if (!pPos)
							{
								pPos = pLastPos;
								bContinue = 0;
								if (strcmp (szOutputStyle, "-ll") == 0)
								{  
									if (bToFile)
										fprintf(fpOutput, "BreakBreakBreak\n");
								}
								break;
							}
							
							if (ii > 0)
							{
								// if this isn't the first sequence in this run, check it's within nMinGap and nMaxGap from the last one
								int nGap = pPos - pLastEndSeq;
								
								if (nGap > nMaxGap )
								{
									// want to use the last position before the gap got too long
									pPos = pLastPos - nMinGap;
									
									// move along until we encounter a non-cBase char (may have long sequence at the end)
									while (*pPos == cBase)
										pPos++;
									
									break;
								}
								else 
								{
									//shunt rolling loop count along
									anRollingLoop[0]=anRollingLoop[1];
									anRollingLoop[1]=anRollingLoop[2];
									anRollingLoop[2]=nGap;
									
									//roll array of Startposes
									apStartPos[0]=apStartPos[1];
									apStartPos[1]=apStartPos[2];
									apStartPos[2]=apStartPos[3];
									apStartPos[3]=pPos;
									
									//if we have three loop values, increment the relevant bit of the array
									if(anRollingLoop[0] >0)
									{
										anLoopCount[anRollingLoop[0]-1] [anRollingLoop[1]-1] [anRollingLoop[2]-1] ++;
										for (kk=0;kk<3;kk++)
										{
											anLoopFrequency[kk][anRollingLoop[kk]-1] ++;
										}										
										jj++;
										if (strcmp(szOutputStyle, "-l2") == 0)
										{
											if (bToFile)
												fprintf(fpOutput, "%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);
											else
												printf("%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);
										}
									}
									
								}
							}
							else
							{
								// otherwise store the start position
								pStartPos = pPos;
								apStartPos[3]=pPos;
							}
							
							// move along to the end of the base sequence + the minimum gap size to look for the next one
							while (*pPos == cBase)
							{
								pPos++;
								n++;
							}
							
							pLastEndSeq = pPos;
							
							// CCCCCCC counts as two strands (CCC)C(CCC)
							ii += (n+1)/(nBasesInRepeat+nMinGap);
							
							if (n >= 2*nBasesInRepeat + nMinGap && n < 3*nBasesInRepeat + 2*nMinGap)
							{
								//we have a new loop found
								//shunt rolling loop count along
								anRollingLoop[0]=anRollingLoop[1];
								anRollingLoop[1]=anRollingLoop[2];
								anRollingLoop[2]=n-2*nBasesInRepeat;
								
								//roll array of Startposes
								apStartPos[0]=apStartPos[1];
								apStartPos[1]=apStartPos[2];
								apStartPos[2]=pPos;
								apStartPos[3]=pPos+n-nBasesInRepeat;
								
								//if we have three loop values, increment the relevant bit of the array
								if(anRollingLoop[0] >0)
								{	
									anLoopCount[anRollingLoop[0]-1] [anRollingLoop[1]-1] [anRollingLoop[2]-1] ++;
									
									for (kk=0;kk<3;kk++)
									{
										anLoopFrequency[kk][anRollingLoop[kk]-1] ++;
									}
									
									jj++;
									if (strcmp(szOutputStyle, "-l2") == 0)
									{
										if (bToFile)
											fprintf(fpOutput,"%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);
										else
											printf("%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);
									}
									
								}
							}
							else if (n>=3*nBasesInRepeat + 2*nMinGap && n <4*nBasesInRepeat + 3*nMinGap)
							{
								//we have two new loops found
								anRollingLoop[0]=anRollingLoop[2];
								anRollingLoop[1]=(int)(n-3*nBasesInRepeat)/2;
								anRollingLoop[2]=(n-3*nBasesInRepeat)-anRollingLoop[1];
								
								apStartPos[0]=apStartPos[1];
								apStartPos[1]=pPos;
								apStartPos[2]=pPos+n-2*nBasesInRepeat-anRollingLoop[2];
								apStartPos[3]=pPos+n-nBasesInRepeat;
								
								//if we have three loop values, increment the relevant bit of the array
								if(anRollingLoop[0] >0)
								{
									anLoopCount[anRollingLoop[0]-1] [anRollingLoop[1]-1] [anRollingLoop[2]-1] ++;
									
									for (kk=0;kk<3;kk++)
									{
										anLoopFrequency[kk][anRollingLoop[kk]-1] ++;
									}
									
									jj++;
									if (strcmp(szOutputStyle, "-l2") == 0)
									{
										if (bToFile)
											fprintf(fpOutput, "%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);
										else
											printf("%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);								
									}
									
								}
							}
							else if (n>4*nBasesInRepeat + 3*nMinGap && n < 5*nBasesInRepeat + 4*nMinGap)
							{
								//we have three new loops found. NB this formula is incorrect for runs equal to ot longer than 5*nBasesInRepeat + 4*nMinGap (normally 19-rare!)
								anRollingLoop[0]=(int)(n-4*nBasesInRepeat)/3;
								anRollingLoop[1]=(int)(n-4*nBasesInRepeat)/3;
								anRollingLoop[2]=(n-4*nBasesInRepeat)-anRollingLoop[1]-anRollingLoop[0];
								anLoopCount[anRollingLoop[0]-1] [anRollingLoop[1]-1] [anRollingLoop[2]-1] ++;
								
								for (kk=0;kk<3;kk++)
								{
									anLoopFrequency[kk][anRollingLoop[kk]-1] ++;
								}
								
								apStartPos[0]=pPos;
								apStartPos[1]=pPos+n-3*nBasesInRepeat-anRollingLoop[1]-anRollingLoop[2];
								apStartPos[2]=pPos+n-2*nBasesInRepeat-anRollingLoop[2];
								apStartPos[3]=pPos+n-nBasesInRepeat;
								
								jj++;
								
								if (strcmp(szOutputStyle, "-l2") == 0)
								{
									if (bToFile)
										fprintf(fpOutput, "%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);
									else
										printf("%d\t%d\t%d\t|\t%d\t%d\n", anRollingLoop[0], anRollingLoop[1], anRollingLoop[2],(pPos+nBasesInRepeat-apStartPos[0]),jj);
								}
								//								printf("long limit");
							}
							//							else if (n>5*nBasesInRepeat + 4*nMinGap)
							//								printf("Exceeded length limit for loops!");
							
							pPos += nMinGap;
						}
						
						if (ii >= nRepeatsInSequence)
						{
							int nOverlappingSequences = ii + 1 - nRepeatsInSequence;
							int nSequences = ii/nRepeatsInSequence;
							
							nOverlappingSequencesFound += nOverlappingSequences;
							nSequencesFound += nSequences;
							nRunsFound ++;
							
							cTemp = *pLastEndSeq;
							*pLastEndSeq = 0;
							
							// if we're here, we found a valid sequence of nRepeatsInSequence or more length - print it out
							
							if (strcmp(szOutputStyle, "-c") == 0 || strcmp(szOutputStyle, "-coord") == 0)
							{
								if (bToFile)
								{
									if (szPrefix) 
										fprintf(fpOutput, "%s,", szPrefix);
									
									fprintf(fpOutput, "%d,%d\n", nChromosomeOffset +(pStartPos - pStartSequence) + 1, nChromosomeOffset + (pLastEndSeq - pStartSequence) );
								}
								else
								{
									if (szPrefix) 
										printf("%s,", szPrefix);
									
									printf("%d,%d\n", nChromosomeOffset + (pStartPos - pStartSequence) + 1, nChromosomeOffset + (pLastEndSeq - pStartSequence) );
								}
							}
									
							if (strcmp(szOutputStyle, "-l3") == 0)
							{
								
								if (bToFile)
									fprintf(fpOutput, "chr%s\t%d\t%d\t%d\t%d\t%d\n", szPrefix, nChromosomeOffset + (pStartPos - pStartSequence), nChromosomeOffset + (pLastEndSeq - pStartSequence), anRollingLoop[0], anRollingLoop[1], anRollingLoop[2]);
								else
									printf("chr%s\t%d\t%d\t%d\t%d\t%d\n", szPrefix, nChromosomeOffset + (pStartPos - pStartSequence), nChromosomeOffset + (pLastEndSeq - pStartSequence), anRollingLoop[0], anRollingLoop[1], anRollingLoop[2]);
							}
							
							if (strcmp(szOutputStyle, "-DAS") == 0)
							{
								
								if (cBase=='C')
									cStrand='-';
								else cStrand='+';
								
								if (bToFile)
								{
									
									//									fprintf(fpOutput, "Quadruplex\tQuad_%d\t%s-rich\tstandard\t%s\t%d\t%d\t+\t.\t.\t.\n",
									//											nSequencesFound, szMatch, szPrefix, nChromosomeOffset +(pStartPos - pStartSequence), nChromosomeOffset + (pLastEndSeq - pStartSequence) - 1);
									
									fprintf(fpOutput, "%s\t%d\t%d\tQuad-%s-%d-%s\t0\t%c\n", szPrefix, nChromosomeOffset +(pStartPos - pStartSequence) + 1 , nChromosomeOffset + (pLastEndSeq - pStartSequence), szMatch, nSequencesFound, pStartPos, cStrand);
									
								}
								else
								{
									
									//									printf("Quadruplex\tQuad_%d\t%s-rich\tstandard\t%s\t%d\t%d\t+\t.\t.\t.\n",
									//											nSequencesFound, szMatch, szPrefix, nChromosomeOffset +(pStartPos - pStartSequence), nChromosomeOffset + (pLastEndSeq - pStartSequence) - 1);
									
									printf("%s\t%d\t%d\tQuad-%s-%d-%s\t0\t%c\n", szPrefix, nChromosomeOffset +(pStartPos - pStartSequence) + 1, nChromosomeOffset + (pLastEndSeq - pStartSequence), szMatch, nSequencesFound, pStartPos, cStrand);
									
								}
							}
							
							if (strcmp(szOutputStyle, "-BED") == 0)
							{
								
								if (cBase=='C')
									cStrand='-';
								else cStrand='+';
								
								if (bToFile)
								{
									
									fprintf(fpOutput, "chr%s\t%d\t%d\tQuad-chr%s-%s-%d-%s\t1000\t%c\n", szPrefix, nChromosomeOffset +(pStartPos - pStartSequence) , nChromosomeOffset + (pLastEndSeq - pStartSequence), szPrefix, szMatch, nSequencesFound, pStartPos, cStrand);
									
								}
								else
								{
									
									printf("chr%s\t%d\t%d\tQuad-chr%s-%s-%d-%s\t1000\t%c\n", szPrefix, nChromosomeOffset +(pStartPos - pStartSequence) , nChromosomeOffset + (pLastEndSeq - pStartSequence),  szPrefix, szMatch, nSequencesFound, pStartPos, cStrand);
									
								}
							}
							
							if (strcmp(szOutputStyle, "-d") == 0 || strcmp(szOutputStyle, "-default") == 0)
							{
								if (bToFile)
									fprintf(fpOutput, "%d-%d\t%d:%d:%d\t%s\n", nChromosomeOffset + (pStartPos - pStartSequence), nChromosomeOffset + (pLastEndSeq - pStartSequence) -1 , ii, nOverlappingSequences, nSequences, pStartPos);
								else
									printf("%d-%d\t%d:%d:%d\t%s\n", nChromosomeOffset + (pStartPos - pStartSequence), nChromosomeOffset + (pLastEndSeq - pStartSequence) -1 ,ii, nOverlappingSequences, nSequences, pStartPos);
							}
							
							if (strcmp(szOutputStyle, "-p") == 0 || strcmp(szOutputStyle, "-pos") == 0)
							{
								if (bToFile)
									fprintf(fpOutput, "%d\n", nChromosomeOffset + (pStartPos - pStartSequence));
								else
									printf("%d\n", nChromosomeOffset + (pStartPos - pStartSequence));
							}
							
							if (strcmp(szOutputStyle, "-m") == 0 || strcmp(szOutputStyle, "-mid") == 0)
							{
								int nStart = nChromosomeOffset + (pStartPos - pStartSequence);
								int nFinish = nChromosomeOffset + (pLastEndSeq - pStartSequence);
								int nMidpoint = 0.5 * (nStart + nFinish);
								if (bToFile)
									fprintf(fpOutput, "%d\n", nMidpoint);
								else
									printf("%d\n", nMidpoint);
							}
							
							if (strcmp(szOutputStyle, "-g") == 0 || 
								strcmp(szOutputStyle, "-gene") ==0 ||
								strcmp(szOutputStyle, "-h") == 0 || 
								strcmp(szOutputStyle, "-header") ==0
								)
							{
								if (bToFile)
									fprintf(fpOutput, "%s\t%s\n", pStartHeader, pStartPos);
								else
									printf("%s\t%s\n", pStartHeader, pStartPos);
							}
							
							*pLastEndSeq = cTemp;
							
						}
						
						pStartPos = NULL;
						pLastEndSeq = NULL;
					}
					
					if (strcmp (szOutputStyle, "-number") == 0 || strcmp(szOutputStyle, "-d") == 0 || strcmp(szOutputStyle, "-default") == 0)
					{
						if (bToFile)
							fprintf(fpOutput, "\nFound %d:%d:%d overlapping:sequences:lines\n", nOverlappingSequencesFound, nSequencesFound, nRunsFound);
						else
							printf("\nFound %d:%d:%d overlapping:sequences:lines\n", nOverlappingSequencesFound, nSequencesFound, nRunsFound);
					}
					
					
					if (strcmp (szOutputStyle, "-loop") == 0 || strcmp(szOutputStyle, "-l") == 0 )
						
					{
						
						for (ii=0; ii<nMaxGap; ii++)
						{
							for (jj=0; jj<nMaxGap; jj++)
							{
								for (kk=0; kk<nMaxGap; kk++)
								{
									//									if(anLoopCount[ii][jj][kk]!=0)
								{
									if (bToFile)
										fprintf(fpOutput, "%d\t%d\t%d\t%d\n", ii+1,jj+1,kk+1,anLoopCount[ii][jj][kk]);
									else
										printf("%d\t%d\t%d\t%d\n", ii+1,jj+1,kk+1,anLoopCount[ii][jj][kk]);
								}
								}
							}
						}
					}
					if (strcmp (szOutputStyle, "-ll") == 0)
						//abbreviated loop display
					{
						//						if (bToFile)
						//							fprintf(fpOutput, "%s\t", pStartHeader);
						//						else
						//							printf("%s\t", pStartHeader);
						
						for (ii=0; ii<nMaxGap; ii++)
						{
							for (jj=0; jj<nMaxGap; jj++)
							{
								for (kk=0; kk<nMaxGap; kk++)
									
								{
									if (bToFile)
										fprintf(fpOutput, "%d\t", anLoopCount[ii][jj][kk]);
									else
										printf("%d\t",anLoopCount[ii][jj][kk]);
									
								}
								if (bToFile)
									fprintf(fpOutput, "\t");
								else
									printf("\t");
							}
							if (bToFile)
								fprintf(fpOutput, "\n");
							else
								printf("\n");
						}
						if (bToFile)
							fprintf(fpOutput, "\n");
						else
							printf("\n");
					}
				}
			}
		}
	}
	
	if (bToFile)
		fclose(fpOutput);
	
	free(szFileContents);
}




